
import { Coin } from './types';

export const MOCK_COINS: Coin[] = [
  {
    id: 'bitcoin',
    symbol: 'BTC',
    name: 'Bitcoin',
    price: 52450.20,
    change24h: 2.45,
    marketCap: '$1.03T',
    volume24h: '$32.1B',
    sparkline: [51000, 51200, 50800, 51500, 52000, 51800, 52450]
  },
  {
    id: 'ethereum',
    symbol: 'ETH',
    name: 'Ethereum',
    price: 3120.45,
    change24h: -1.20,
    marketCap: '$375.2B',
    volume24h: '$15.4B',
    sparkline: [3200, 3150, 3180, 3100, 3120, 3080, 3120]
  },
  {
    id: 'solana',
    symbol: 'SOL',
    name: 'Solana',
    price: 142.15,
    change24h: 5.67,
    marketCap: '$63.2B',
    volume24h: '$4.2B',
    sparkline: [130, 135, 132, 138, 140, 139, 142]
  },
  {
    id: 'binancecoin',
    symbol: 'BNB',
    name: 'BNB',
    price: 585.30,
    change24h: 0.15,
    marketCap: '$87.1B',
    volume24h: '$1.8B',
    sparkline: [580, 582, 581, 584, 585, 583, 585]
  },
  {
    id: 'ripple',
    symbol: 'XRP',
    name: 'XRP',
    price: 0.62,
    change24h: -0.45,
    marketCap: '$34.2B',
    volume24h: '$1.2B',
    sparkline: [0.63, 0.61, 0.62, 0.60, 0.63, 0.62, 0.62]
  },
  {
    id: 'cardano',
    symbol: 'ADA',
    name: 'Cardano',
    price: 0.58,
    change24h: 1.12,
    marketCap: '$20.5B',
    volume24h: '$600M',
    sparkline: [0.55, 0.57, 0.56, 0.58, 0.59, 0.57, 0.58]
  }
];
