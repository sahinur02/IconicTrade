
// This file has been deprecated and replaced by AuthPage.tsx
export {}
