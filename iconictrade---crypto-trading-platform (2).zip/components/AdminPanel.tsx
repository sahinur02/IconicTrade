
import React, { useState, useEffect } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  IndianRupee,
  Search,
  TrendingUp,
  Settings as SettingsIcon,
  Trash2,
  Ban,
  ExternalLink,
  Filter,
  RefreshCw,
  Plus,
  Palette,
  Type,
  ImageIcon,
  CreditCard,
  Key,
  Globe,
  ArrowUpRight,
  ArrowDownRight,
  PieChart as PieChartIcon,
  X
} from 'lucide-react';
import { MOCK_COINS } from '../constants';
import { Coin } from '../types';

const MOCK_USERS = [
  { id: '1', name: 'Rahul Sharma', email: 'rahul@gmail.com', balance: 12400, kyc: 'Verified', volume: '₹1.2L', status: 'Active' },
  { id: '2', name: 'Anita Desai', email: 'anita.d@outlook.com', balance: 4500, kyc: 'Pending', volume: '₹45K', status: 'Active' },
  { id: '3', name: 'Vikram Singh', email: 'vikram1990@yahoo.com', balance: 89200, kyc: 'Verified', volume: '₹15.8L', status: 'Active' },
];

const AdminPanel: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'markets' | 'finance' | 'settings'>('users');
  const [users, setUsers] = useState(MOCK_USERS);
  
  // Coin management state
  const [customCoins, setCustomCoins] = useState<Coin[]>([]);
  const [isAddingCoin, setIsAddingCoin] = useState(false);
  const [newCoin, setNewCoin] = useState({
    name: '',
    symbol: '',
    price: '',
    change24h: '',
    logoUrl: ''
  });

  const [branding, setBranding] = useState({
    name: localStorage.getItem('platform_name') || 'IconicTrade',
    initial: localStorage.getItem('platform_initial') || 'I',
    tagline: localStorage.getItem('platform_tagline') || 'Next Gen Trading',
    logoUrl: localStorage.getItem('platform_logo_url') || ''
  });

  const [paymentConfig, setPaymentConfig] = useState({
    razorpayKeyId: localStorage.getItem('rzp_key_id') || '',
    isLive: localStorage.getItem('rzp_mode') === 'live'
  });

  useEffect(() => {
    const saved = localStorage.getItem('custom_platform_coins');
    if (saved) setCustomCoins(JSON.parse(saved));
  }, []);

  const saveCustomCoins = (updated: Coin[]) => {
    setCustomCoins(updated);
    localStorage.setItem('custom_platform_coins', JSON.stringify(updated));
    window.dispatchEvent(new Event('coins-update'));
  };

  const handleAddCoin = (e: React.FormEvent) => {
    e.preventDefault();
    const coinToAdd: Coin = {
      id: `custom-${Date.now()}`,
      name: newCoin.name,
      symbol: newCoin.symbol.toUpperCase(),
      price: parseFloat(newCoin.price) || 0,
      change24h: parseFloat(newCoin.change24h) || 0,
      marketCap: '₹0',
      volume24h: '₹0',
      sparkline: [50, 52, 48, 55, 60, 58, 62], // Default sparkline
      logoUrl: newCoin.logoUrl || undefined
    };

    saveCustomCoins([...customCoins, coinToAdd]);
    setNewCoin({ name: '', symbol: '', price: '', change24h: '', logoUrl: '' });
    setIsAddingCoin(false);
  };

  const handleDeleteCoin = (id: string) => {
    if (confirm("Are you sure you want to remove this asset from the market?")) {
      saveCustomCoins(customCoins.filter(c => c.id !== id));
    }
  };

  const saveSettings = () => {
    localStorage.setItem('platform_name', branding.name);
    localStorage.setItem('platform_initial', branding.initial);
    localStorage.setItem('platform_tagline', branding.tagline);
    localStorage.setItem('platform_logo_url', branding.logoUrl);
    localStorage.setItem('rzp_key_id', paymentConfig.razorpayKeyId);
    localStorage.setItem('rzp_mode', paymentConfig.isLive ? 'live' : 'test');
    
    window.dispatchEvent(new Event('branding-update'));
    window.dispatchEvent(new Event('config-update'));
    alert("System Configurations Updated Successfully!");
  };

  const allCoins = [...MOCK_COINS, ...customCoins];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">Command Center</h2>
          <p className="text-slate-500 font-bold uppercase tracking-[0.2em] text-[10px] mt-1">{branding.name} Executive Terminal</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 bg-slate-900/50 p-1.5 rounded-[1.5rem] border border-slate-800 w-fit">
        {[
          { id: 'users', label: 'Users', icon: Users },
          { id: 'markets', label: 'Markets', icon: TrendingUp },
          { id: 'finance', label: 'Finance', icon: IndianRupee },
          { id: 'settings', label: 'Settings', icon: SettingsIcon },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`flex items-center gap-3 px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
              activeSubTab === tab.id 
                ? 'bg-purple-600 text-white shadow-lg' 
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="space-y-8">
        {activeSubTab === 'markets' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-xl">
                <div className="p-8 border-b border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                   <div>
                     <h3 className="text-xl font-black text-white">Market Asset Management</h3>
                     <p className="text-xs text-slate-500 font-bold">Manage coins visible on the public exchange</p>
                   </div>
                   <button 
                    onClick={() => setIsAddingCoin(true)}
                    className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all"
                   >
                     <Plus size={18} /> Add New Asset
                   </button>
                </div>

                {isAddingCoin && (
                  <div className="p-8 bg-slate-800/20 border-b border-slate-800 animate-in fade-in duration-300">
                    <form onSubmit={handleAddCoin} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-end">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Coin Name</label>
                        <input type="text" required value={newCoin.name} onChange={e => setNewCoin({...newCoin, name: e.target.value})} placeholder="e.g. Bitcoin" className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-xs font-bold text-white focus:outline-none focus:ring-1 focus:ring-blue-500" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Symbol</label>
                        <input type="text" required value={newCoin.symbol} onChange={e => setNewCoin({...newCoin, symbol: e.target.value})} placeholder="e.g. BTC" className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-xs font-bold text-white focus:outline-none focus:ring-1 focus:ring-blue-500" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Price (INR)</label>
                        <input type="number" step="any" required value={newCoin.price} onChange={e => setNewCoin({...newCoin, price: e.target.value})} placeholder="Current Price" className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-xs font-bold text-white focus:outline-none focus:ring-1 focus:ring-blue-500" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Logo URL (Optional)</label>
                        <input type="text" value={newCoin.logoUrl} onChange={e => setNewCoin({...newCoin, logoUrl: e.target.value})} placeholder="https://..." className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 px-4 text-xs font-bold text-white focus:outline-none focus:ring-1 focus:ring-blue-500" />
                      </div>
                      <div className="flex gap-2">
                        <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Save</button>
                        <button type="button" onClick={() => setIsAddingCoin(false)} className="bg-slate-700 hover:bg-slate-600 text-white p-2.5 rounded-xl transition-all"><X size={18} /></button>
                      </div>
                    </form>
                  </div>
                )}

                <table className="w-full text-left">
                   <thead className="bg-slate-800/30">
                     <tr>
                       <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Asset</th>
                       <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Symbol</th>
                       <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Price</th>
                       <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Change</th>
                       <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">Action</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-800">
                     {allCoins.map(c => (
                       <tr key={c.id} className="hover:bg-slate-800/20 transition-colors">
                         <td className="px-8 py-5">
                            <div className="flex items-center gap-3">
                              {c.logoUrl ? (
                                <img src={c.logoUrl} alt={c.name} className="w-8 h-8 rounded-full object-cover border border-slate-700" />
                              ) : (
                                <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center font-black text-[10px] text-white">
                                  {c.symbol[0]}
                                </div>
                              )}
                              <span className="font-black text-white text-sm">{c.name}</span>
                            </div>
                         </td>
                         <td className="px-8 py-5 font-bold text-slate-500 text-xs">{c.symbol}</td>
                         <td className="px-8 py-5 font-black text-white text-sm">₹{c.price.toLocaleString()}</td>
                         <td className="px-8 py-5">
                            <span className={`text-[10px] font-black uppercase ${c.change24h >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                               {c.change24h}%
                            </span>
                         </td>
                         <td className="px-8 py-5 text-right">
                            {c.id.toString().startsWith('custom') && (
                              <button 
                                onClick={() => handleDeleteCoin(c.id)}
                                className="p-2.5 hover:bg-rose-600/10 text-rose-500 rounded-xl transition-all"
                              >
                                <Trash2 size={18} />
                              </button>
                            )}
                         </td>
                       </tr>
                     ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {activeSubTab === 'finance' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Total Volume', value: '₹48.2M', icon: Activity, color: 'text-blue-500' },
                  { label: 'Total Deposits', value: '₹12.5M', icon: ArrowDownRight, color: 'text-emerald-500' },
                  { label: 'Total Withdrawals', value: '₹8.1M', icon: ArrowUpRight, color: 'text-rose-500' },
                  { label: 'Net Profit (Fees)', value: '₹420K', icon: IndianRupee, color: 'text-amber-500' },
                ].map((stat, i) => (
                  <div key={i} className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] shadow-xl">
                    <stat.icon size={24} className={`${stat.color} mb-6`} />
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">{stat.label}</p>
                    <h4 className="text-3xl font-black text-white mt-1">{stat.value}</h4>
                  </div>
                ))}
             </div>

             <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-10">
                <div className="flex items-center justify-between mb-8">
                   <h3 className="text-2xl font-black text-white flex items-center gap-3">
                      <PieChartIcon className="text-purple-500" /> Platform Reserves
                   </h3>
                </div>
                <div className="space-y-4">
                   {[
                     { name: 'INR Escrow', amount: '₹14,500,200', pct: 65, color: 'bg-blue-600' },
                     { name: 'BTC Hot Wallet', amount: '4.25 BTC', pct: 20, color: 'bg-amber-500' },
                     { name: 'ETH Hot Wallet', amount: '58.2 ETH', pct: 15, color: 'bg-indigo-500' },
                   ].map((asset, i) => (
                     <div key={i} className="space-y-2">
                        <div className="flex justify-between text-xs font-bold">
                           <span className="text-white">{asset.name}</span>
                           <span className="text-slate-500">{asset.amount}</span>
                        </div>
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                           <div className={`h-full ${asset.color}`} style={{ width: `${asset.pct}%` }}></div>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
          </div>
        )}

        {activeSubTab === 'settings' && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-10">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-purple-600/10 rounded-2xl flex items-center justify-center text-purple-500">
                  <Palette size={24} />
                </div>
                <h3 className="text-2xl font-black text-white">Branding & Identity</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Platform Name</label>
                  <input 
                    type="text" 
                    value={branding.name}
                    onChange={(e) => setBranding({...branding, name: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-4 text-white font-bold focus:ring-2 focus:ring-purple-600 focus:outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Logo Letter</label>
                  <input 
                    type="text" 
                    maxLength={1}
                    value={branding.initial}
                    onChange={(e) => setBranding({...branding, initial: e.target.value.toUpperCase()})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-4 text-white font-black text-center text-2xl focus:ring-2 focus:ring-purple-600 focus:outline-none"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Platform Logo URL</label>
                  <input 
                    type="text" 
                    value={branding.logoUrl}
                    onChange={(e) => setBranding({...branding, logoUrl: e.target.value})}
                    placeholder="https://example.com/logo.png"
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-4 text-white font-bold focus:ring-2 focus:ring-purple-600 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-10 flex flex-col">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-600/10 rounded-2xl flex items-center justify-center text-blue-500">
                    <CreditCard size={24} />
                  </div>
                  <h3 className="text-2xl font-black text-white">Razorpay Gateway</h3>
                </div>
                <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${paymentConfig.razorpayKeyId ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20'}`}>
                   {paymentConfig.razorpayKeyId ? 'Connected' : 'Disconnected'}
                </div>
              </div>

              <div className="space-y-6 flex-1">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Razorpay Key ID</label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input 
                      type="text" 
                      value={paymentConfig.razorpayKeyId}
                      onChange={(e) => setPaymentConfig({...paymentConfig, razorpayKeyId: e.target.value})}
                      placeholder="rzp_test_XXXXXXXXXXXXXX"
                      className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white font-mono text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-slate-700">
                   <div className="flex items-center gap-3">
                      <Globe size={18} className="text-slate-400" />
                      <div>
                        <p className="text-xs font-black text-white uppercase tracking-widest">Environment</p>
                        <p className="text-[10px] text-slate-500 font-bold">{paymentConfig.isLive ? 'Live Production Mode' : 'Testing Sandbox Mode'}</p>
                      </div>
                   </div>
                   <button 
                    onClick={() => setPaymentConfig({...paymentConfig, isLive: !paymentConfig.isLive})}
                    className={`w-12 h-6 rounded-full transition-all relative ${paymentConfig.isLive ? 'bg-emerald-600' : 'bg-slate-700'}`}
                   >
                     <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${paymentConfig.isLive ? 'right-1' : 'left-1'}`}></div>
                   </button>
                </div>
              </div>
            </div>

            <div className="xl:col-span-2 pt-6">
              <button 
                onClick={saveSettings}
                className="w-full bg-purple-600 hover:bg-purple-500 text-white py-6 rounded-[2rem] font-black text-sm tracking-widest shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3"
              >
                <CheckCircle2 size={24} />
                APPLY GLOBAL CONFIGURATIONS
              </button>
            </div>
          </div>
        )}

        {activeSubTab === 'users' && (
          <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-xl">
             <div className="p-8 border-b border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <h3 className="text-xl font-black text-white">Registered Traders</h3>
                <div className="relative w-full md:w-80">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                  <input type="text" placeholder="Search by name or email..." className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 pl-12 pr-4 text-xs font-bold text-white focus:outline-none" />
                </div>
             </div>
             <table className="w-full text-left">
               <thead className="bg-slate-800/30">
                 <tr>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Trader</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">KYC Status</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Balance</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">Action</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-800">
                 {users.map(u => (
                   <tr key={u.id} className="hover:bg-slate-800/20 transition-colors">
                     <td className="px-8 py-6">
                        <div className="font-black text-white text-sm">{u.name}</div>
                        <div className="text-[10px] text-slate-500 font-bold">{u.email}</div>
                     </td>
                     <td className="px-8 py-6">
                        <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${u.kyc === 'Verified' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-amber-500/10 text-amber-500 border-amber-500/20'}`}>
                           {u.kyc}
                        </span>
                     </td>
                     <td className="px-8 py-6 font-black text-white">₹{u.balance.toLocaleString()}</td>
                     <td className="px-8 py-6 text-right space-x-2">
                        <button className="p-2 hover:bg-blue-600/10 text-blue-500 rounded-lg transition-colors"><Activity size={18} /></button>
                        <button className="p-2 hover:bg-rose-600/10 text-rose-500 rounded-lg transition-colors"><Ban size={18} /></button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
