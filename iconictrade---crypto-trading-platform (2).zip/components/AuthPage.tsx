
import React, { useState, useEffect } from 'react';
import { Mail, Lock, User, Chrome, Apple, ArrowRight, ShieldCheck, Loader2, ArrowLeft, TrendingUp, Shield, Zap } from 'lucide-react';

interface AuthPageProps {
  initialMode: 'login' | 'signup';
  onSuccess: (userData: { name: string; email: string }, isNewUser: boolean) => void;
  onBack: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ initialMode, onSuccess, onBack }) => {
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const [branding, setBranding] = useState({
    name: localStorage.getItem('platform_name') || 'IconicTrade',
    initial: localStorage.getItem('platform_initial') || 'I',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulation of network request
    setTimeout(() => {
      setIsLoading(false);
      onSuccess({ 
        name: mode === 'signup' ? name : 'Pro Trader', 
        email: email || 'trader@iconictrade.com' 
      }, mode === 'signup');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col lg:flex-row overflow-hidden relative">
      {/* Decorative Gradients */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-600/10 blur-[150px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-indigo-600/10 blur-[120px] rounded-full translate-y-1/2 -translate-x-1/2"></div>

      {/* Left Column: Marketing & Branding */}
      <div className="hidden lg:flex lg:w-1/2 p-20 flex-col justify-between relative z-10 border-r border-slate-800/50">
        <div>
          <div className="flex items-center gap-4 mb-20 cursor-pointer hover:scale-105 transition-transform w-fit" onClick={onBack}>
            <div className="w-14 h-14 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center font-black text-white text-3xl italic shadow-2xl shadow-blue-900/40">
              {branding.initial}
            </div>
            <h1 className="text-4xl font-black text-white tracking-tighter">{branding.name}</h1>
          </div>

          <div className="space-y-12">
            <h2 className="text-6xl font-black text-white leading-[1.1] tracking-tight">
              India's Most <span className="text-blue-500">Trusted</span> <br /> Crypto Exchange.
            </h2>
            
            <div className="space-y-8">
              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-center text-blue-500 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-xl">
                  <Shield size={28} />
                </div>
                <div>
                  <h4 className="text-white font-black text-lg">Bank-Grade Security</h4>
                  <p className="text-slate-400 font-medium">98% of assets are stored in multi-sig cold wallets.</p>
                </div>
              </div>
              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-center text-emerald-500 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-xl">
                  <Zap size={28} />
                </div>
                <div>
                  <h4 className="text-white font-black text-lg">Instant Settlements</h4>
                  <p className="text-slate-400 font-medium">Deposit and withdraw INR instantly via UPI 24/7.</p>
                </div>
              </div>
              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-center text-amber-500 group-hover:bg-amber-600 group-hover:text-white transition-all shadow-xl">
                  <TrendingUp size={28} />
                </div>
                <div>
                  <h4 className="text-white font-black text-lg">Zero-Fee Trading</h4>
                  <p className="text-slate-400 font-medium">Join today and pay 0% fees for your first 30 days.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-slate-500 text-xs font-bold uppercase tracking-[0.3em] flex items-center gap-2">
          <ShieldCheck size={16} className="text-emerald-500" />
          Regulated and compliant trading platform
        </div>
      </div>

      {/* Right Column: Auth Forms */}
      <div className="flex-1 flex flex-col justify-center items-center p-8 lg:p-20 relative z-10">
        <button 
          onClick={onBack}
          className="lg:hidden absolute top-8 left-8 text-slate-400 flex items-center gap-2 font-black text-xs tracking-widest uppercase hover:text-white transition-all"
        >
          <ArrowLeft size={16} /> Back
        </button>

        <div className="w-full max-w-md space-y-10 animate-in fade-in slide-in-from-right-10 duration-700">
          <div className="lg:hidden flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center font-black text-white text-3xl italic mb-4">
              {branding.initial}
            </div>
            <h1 className="text-3xl font-black text-white tracking-tighter">{branding.name}</h1>
          </div>

          <div>
            <h2 className="text-4xl font-black text-white tracking-tight leading-tight">
              {mode === 'login' ? 'Welcome Back' : 'Get Started'}
            </h2>
            <p className="text-slate-500 mt-2 font-medium">
              {mode === 'login' 
                ? 'Sign in to access your dashboard and markets.' 
                : 'Join 10M+ traders and start building your portfolio.'}
            </p>
          </div>

          <div className="flex bg-slate-900 border border-slate-800 p-1.5 rounded-2xl shadow-inner">
            <button 
              onClick={() => setMode('login')}
              className={`flex-1 py-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'login' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Log In
            </button>
            <button 
              onClick={() => setMode('signup')}
              className={`flex-1 py-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'signup' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'signup' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                  <input 
                    type="text" 
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-5 pl-12 pr-4 text-white font-bold focus:ring-2 focus:ring-blue-600/50 focus:outline-none transition-all"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-5 pl-12 pr-4 text-white font-bold focus:ring-2 focus:ring-blue-600/50 focus:outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between px-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Password</label>
                {mode === 'login' && <button type="button" className="text-[10px] text-blue-500 font-black uppercase tracking-widest hover:underline">Forgot?</button>}
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-5 pl-12 pr-4 text-white font-bold focus:ring-2 focus:ring-blue-600/50 focus:outline-none transition-all"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-6 rounded-[2rem] font-black text-sm tracking-widest uppercase shadow-2xl shadow-blue-900/40 flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
            >
              {isLoading ? <Loader2 className="animate-spin" size={24} /> : (
                <>
                  {mode === 'login' ? 'Secure Access' : 'Create My Account'}
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
            <div className="relative flex justify-center text-[10px] uppercase"><span className="bg-slate-950 px-4 text-slate-600 font-black tracking-widest">Third-Party Login</span></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-3 py-4 bg-slate-900 border border-slate-800 rounded-2xl hover:bg-slate-800 transition-all font-black text-[10px] text-slate-400 uppercase tracking-widest">
              <Chrome size={18} /> Google
            </button>
            <button className="flex items-center justify-center gap-3 py-4 bg-slate-900 border border-slate-800 rounded-2xl hover:bg-slate-800 transition-all font-black text-[10px] text-slate-400 uppercase tracking-widest">
              <Apple size={18} /> Apple
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
