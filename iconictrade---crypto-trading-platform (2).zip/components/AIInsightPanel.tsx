
import React, { useState, useEffect } from 'react';
import { Sparkles, BrainCircuit, Target, ShieldAlert, Loader2, Send, LineChart } from 'lucide-react';
import { getMarketAnalysis, getAITradingAdvisor } from '../services/gemini';
import { AIInsight, Coin } from '../types';

interface AIInsightPanelProps {
  coin: Coin;
}

const AIInsightPanel: React.FC<AIInsightPanelProps> = ({ coin }) => {
  const [insight, setInsight] = useState<AIInsight | null>(null);
  const [loading, setLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatResponse, setChatResponse] = useState<string | null>(null);
  const [chatLoading, setChatLoading] = useState(false);

  useEffect(() => {
    const fetchInsight = async () => {
      setLoading(true);
      const data = await getMarketAnalysis(coin.name, coin.price, coin.change24h);
      setInsight(data);
      setLoading(false);
    };
    fetchInsight();
  }, [coin]);

  const handleChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatLoading(true);
    const response = await getAITradingAdvisor(chatInput);
    setChatResponse(response);
    setChatLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-blue-900/20 to-slate-900 border border-blue-500/30 rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Sparkles size={120} className="text-blue-400" />
        </div>
        
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-blue-900/40">
            <BrainCircuit size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Gemini Pro Analysis</h3>
            <p className="text-sm text-slate-400">Deep market insights for {coin.name}</p>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <Loader2 size={40} className="text-blue-500 animate-spin" />
            <p className="text-slate-400 text-sm animate-pulse">Consulting global markets...</p>
          </div>
        ) : insight ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1">
                <Target size={14} className="text-blue-400" /> Sentiment
              </label>
              <div className={`text-2xl font-black ${
                insight.sentiment === 'Bullish' ? 'text-emerald-400' : 
                insight.sentiment === 'Bearish' ? 'text-rose-400' : 'text-amber-400'
              }`}>
                {insight.sentiment}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {insight.summary}
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1">
                <LineChart size={14} className="text-blue-400" /> Technical Levels
              </label>
              <div className="flex flex-wrap gap-2">
                {insight.keyLevels.map((level, i) => (
                  <span key={i} className="px-3 py-1 bg-slate-800 rounded-full text-xs text-slate-200 border border-slate-700">
                    {level}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1">
                <ShieldAlert size={14} className="text-rose-400" /> Risk Factor
              </label>
              <p className="text-sm text-slate-300 italic">
                "{insight.riskFactor}"
              </p>
            </div>
          </div>
        ) : (
          <p className="text-center py-10 text-slate-500">Analysis unavailable at the moment.</p>
        )}
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
          <Sparkles size={18} className="text-blue-400" />
          Ask IconicTrade AI Advisor
        </h3>
        
        <form onSubmit={handleChat} className="flex gap-2">
          <input 
            type="text" 
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Should I hold ETH or buy the dip in SOL?"
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <button 
            disabled={chatLoading}
            className="bg-blue-600 hover:bg-blue-500 text-white px-6 rounded-xl font-bold transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {chatLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
          </button>
        </form>

        {chatResponse && (
          <div className="mt-6 p-4 bg-slate-800/50 rounded-xl border-l-4 border-blue-500 animate-in slide-in-from-top-2">
            <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
              {chatResponse}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIInsightPanel;
