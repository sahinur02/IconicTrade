
import React, { useState } from 'react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { Coin } from '../types';
import { Zap, CheckCircle2, Loader2, IndianRupee } from 'lucide-react';

interface TradingViewProps {
  selectedCoin: Coin;
  availableBalance: number;
  portfolioAssets: { symbol: string, amount: number }[];
  onTrade: (side: 'buy' | 'sell', qty: number) => void;
}

const TradingView: React.FC<TradingViewProps> = ({ selectedCoin, availableBalance, portfolioAssets, onTrade }) => {
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [isOrdering, setIsOrdering] = useState(false);
  const [orderStatus, setOrderStatus] = useState<'idle' | 'success'>('idle');

  const assetHolding = portfolioAssets.find(a => a.symbol === selectedCoin.symbol)?.amount || 0;
  const estimatedValue = Number(amount) * selectedCoin.price;

  const handleTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = Number(amount);
    
    if (!qty || isNaN(qty) || qty <= 0) return;

    if (side === 'buy') {
      if (estimatedValue < 1) {
        alert("Minimum buy value is ₹1.");
        return;
      }
      if (estimatedValue > availableBalance) {
        alert("Insufficient INR balance to buy.");
        return;
      }
    } else {
      if (qty > assetHolding) {
        alert(`You only have ${assetHolding.toFixed(6)} ${selectedCoin.symbol} to sell.`);
        return;
      }
    }
    
    setIsOrdering(true);
    setTimeout(() => {
      setIsOrdering(false);
      setOrderStatus('success');
      onTrade(side, qty);
      setAmount('');
      setTimeout(() => setOrderStatus('idle'), 3000);
    }, 1200);
  };

  const data = Array.from({ length: 24 }, (_, i) => ({
    time: `${i}:00`,
    price: selectedCoin.price * (0.95 + Math.random() * 0.1)
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-[2rem] p-8 shadow-inner">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center font-black text-xl text-white">
              {selectedCoin.symbol[0]}
            </div>
            <div>
              <h2 className="text-3xl font-black text-white">
                {selectedCoin.symbol}/INR
                <span className={`ml-3 text-sm px-3 py-1 rounded-full font-bold ${selectedCoin.change24h > 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                  {selectedCoin.change24h}%
                </span>
              </h2>
              <p className="text-slate-500 font-medium text-sm">{selectedCoin.name} Live Spot Chart</p>
            </div>
          </div>
        </div>

        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="chartColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" opacity={0.5} />
              <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis domain={['auto', 'auto']} stroke="#475569" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(val) => `₹${val.toLocaleString()}`} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '16px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="price" stroke="#3b82f6" strokeWidth={4} fill="url(#chartColor)" animationDuration={1000} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-[2rem] overflow-hidden flex flex-col shadow-2xl">
        <div className="flex p-2 bg-slate-800/50">
          <button onClick={() => setSide('buy')} className={`flex-1 py-3.5 font-black rounded-2xl transition-all ${side === 'buy' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}>BUY</button>
          <button onClick={() => setSide('sell')} className={`flex-1 py-3.5 font-black rounded-2xl transition-all ${side === 'sell' ? 'bg-rose-600 text-white' : 'text-slate-500'}`}>SELL</button>
        </div>

        <div className="p-8 flex-1 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
              {side === 'buy' ? 'Available INR' : `Owned ${selectedCoin.symbol}`}
            </span>
            <span className="text-sm font-black text-white">
              {side === 'buy' ? `₹${availableBalance.toLocaleString()}` : assetHolding.toFixed(4)}
            </span>
          </div>

          <form onSubmit={handleTrade} className="space-y-6 flex-1">
            <div className="space-y-2">
              <label className="block text-[10px] text-slate-500 uppercase font-black tracking-widest flex justify-between">
                <span>Quantity ({selectedCoin.symbol})</span>
                {side === 'sell' && <button type="button" onClick={() => setAmount(assetHolding.toString())} className="text-blue-500 hover:underline">MAX</button>}
              </label>
              <input type="number" step="any" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-5 text-white font-bold focus:outline-none" />
            </div>

            {amount && (
              <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl flex justify-between items-center">
                <span className="text-[10px] font-black text-slate-500 uppercase">Est. Value</span>
                <span className="text-sm font-black text-white">₹{estimatedValue.toLocaleString()}</span>
              </div>
            )}

            <button type="submit" disabled={isOrdering || !amount} className={`w-full py-5 rounded-[1.5rem] font-black flex items-center justify-center gap-3 transition-all ${side === 'buy' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'}`}>
              {isOrdering ? <Loader2 size={24} className="animate-spin" /> : <Zap size={24} fill="currentColor" />}
              {side === 'buy' ? 'BUY' : 'SELL'} {selectedCoin.symbol}
            </button>
          </form>

          {orderStatus === 'success' && (
            <div className="mt-4 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3 animate-scale-in">
              <CheckCircle2 size={20} className="text-emerald-500" />
              <div className="text-xs font-bold text-emerald-500 uppercase">Trade Successful!</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TradingView;
