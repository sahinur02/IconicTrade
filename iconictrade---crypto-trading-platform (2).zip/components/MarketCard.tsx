
import React from 'react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import { Coin } from '../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketCardProps {
  coin: Coin;
  onClick: () => void;
}

const MarketCard: React.FC<MarketCardProps> = ({ coin, onClick }) => {
  const isPositive = coin.change24h > 0;
  const data = coin.sparkline.map((val, i) => ({ value: val }));

  return (
    <div 
      onClick={onClick}
      className="bg-slate-900/50 border border-slate-800 p-5 rounded-2xl hover:bg-slate-800/80 transition-all cursor-pointer group"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-3">
          {coin.logoUrl ? (
            <img 
              src={coin.logoUrl} 
              alt={coin.name} 
              className="w-10 h-10 rounded-xl object-cover border border-slate-700 shadow-lg group-hover:border-blue-500 transition-all"
            />
          ) : (
            <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center font-bold text-white transition-all group-hover:bg-blue-600">
              {coin.symbol[0]}
            </div>
          )}
          <div>
            <h3 className="font-bold text-slate-100">{coin.symbol}/INR</h3>
            <p className="text-xs text-slate-500">{coin.name}</p>
          </div>
        </div>
        <div className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
          {isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
          {Math.abs(coin.change24h)}%
        </div>
      </div>

      <div className="flex justify-between items-end">
        <div>
          <p className="text-2xl font-bold text-white">₹{coin.price.toLocaleString()}</p>
          <p className="text-xs text-slate-500">Vol: {coin.volume24h}</p>
        </div>
        <div className="w-24 h-12">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id={`gradient-${coin.id}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke={isPositive ? '#10b981' : '#f43f5e'} 
                strokeWidth={2}
                fillOpacity={1} 
                fill={`url(#gradient-${coin.id})`} 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default MarketCard;
