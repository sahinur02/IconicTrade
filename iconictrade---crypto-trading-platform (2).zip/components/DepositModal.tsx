
import React, { useState, useEffect } from 'react';
import { X, IndianRupee, ShieldCheck, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (amount: number) => void;
}

const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [amount, setAmount] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success'>('idle');
  const [rzpKey, setRzpKey] = useState(localStorage.getItem('rzp_key_id') || '');

  useEffect(() => {
    const handleUpdate = () => {
      setRzpKey(localStorage.getItem('rzp_key_id') || '');
    };
    window.addEventListener('config-update', handleUpdate);
    return () => window.removeEventListener('config-update', handleUpdate);
  }, []);

  if (!isOpen) return null;

  const handleRazorpay = () => {
    if (!amount || isNaN(Number(amount)) || Number(amount) < 100) {
      alert("Please enter a valid amount (Min ₹100)");
      return;
    }

    if (!rzpKey) {
      alert("Payment gateway is currently not configured by Admin. Please contact support.");
      return;
    }

    setLoading(true);

    const options = {
      key: rzpKey, // Use the dynamic key from admin panel
      amount: Number(amount) * 100, // Razorpay works in paise
      currency: "INR",
      name: localStorage.getItem('platform_name') || "IconicTrade",
      description: "Wallet Deposit",
      image: localStorage.getItem('platform_logo_url') || "https://picsum.photos/seed/iconictrade/200",
      handler: function (response: any) {
        setLoading(false);
        setStatus('success');
        setTimeout(() => {
          onSuccess(Number(amount));
          setStatus('idle');
          setAmount('');
          onClose();
        }, 2000);
      },
      prefill: {
        name: "Trader",
        email: "user@example.com"
      },
      theme: {
        color: "#2563eb"
      },
      modal: {
        ondismiss: function() {
          setLoading(false);
        }
      }
    };

    try {
      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', function (response: any) {
        setLoading(false);
        alert("Payment Failed: " + response.error.description);
      });
      rzp.open();
    } catch (err) {
      setLoading(false);
      alert("Failed to initialize Razorpay. Please check if the Key ID in Admin Panel is correct.");
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl overflow-hidden shadow-2xl animate-scale-in">
        
        {status === 'success' ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-20 h-20 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={48} className="animate-bounce" />
            </div>
            <h3 className="text-2xl font-bold text-white tracking-tight">Deposit Successful!</h3>
            <p className="text-slate-400 font-medium">₹{amount} has been added to your IconicTrade wallet.</p>
          </div>
        ) : (
          <>
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/30">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                  <IndianRupee size={18} />
                </div>
                <h3 className="font-black text-white text-lg tracking-tight">Add Funds</h3>
              </div>
              <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors bg-white/5 p-2 rounded-xl">
                <X size={20} />
              </button>
            </div>

            <div className="p-8 space-y-6">
              {!rzpKey && (
                <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex items-start gap-3">
                  <AlertTriangle className="text-rose-500 shrink-0" size={18} />
                  <p className="text-[10px] text-rose-400 font-bold uppercase tracking-widest leading-relaxed">
                    Gateway Error: Razorpay Key not configured in Admin Panel. Deposits are disabled.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Enter Amount (INR)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black">₹</span>
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-10 pr-4 text-2xl font-bold text-white focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all placeholder:text-slate-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {[100, 500, 1000].map((val) => (
                  <button 
                    key={val}
                    onClick={() => setAmount(val.toString())}
                    className="py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-slate-400 hover:bg-slate-700 hover:text-white transition-all uppercase tracking-widest"
                  >
                    +₹{val}
                  </button>
                ))}
              </div>

              <div className="space-y-4 pt-2">
                <button 
                  onClick={handleRazorpay}
                  disabled={loading || !rzpKey}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white py-5 rounded-2xl font-black text-xs tracking-widest uppercase shadow-xl shadow-blue-900/40 flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Zap size={20} fill="currentColor" />
                      INSTANT UPI DEPOSIT
                    </>
                  )}
                </button>
                <div className="flex items-center justify-center gap-6 opacity-40">
                   <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/UPI-Logo-vector.svg/1200px-UPI-Logo-vector.svg.png" alt="UPI" className="h-4 grayscale invert" />
                   <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Razorpay_logo.svg/1200px-Razorpay_logo.svg.png" alt="Razorpay" className="h-3 grayscale invert" />
                </div>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-xl flex items-start gap-3 border border-slate-800">
                <ShieldCheck className="text-emerald-500 shrink-0" size={18} />
                <p className="text-[9px] text-slate-500 leading-relaxed font-medium uppercase tracking-wider">
                  RBI Compliant Escrow Protection Active. Payments are 100% Secure.
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default DepositModal;
