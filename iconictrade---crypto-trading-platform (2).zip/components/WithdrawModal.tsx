
import React, { useState } from 'react';
import { X, IndianRupee, ShieldCheck, ArrowUpRight, CheckCircle2, Building, User, Hash, Info } from 'lucide-react';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (amount: number) => void;
  currentBalance: number;
}

const WithdrawModal: React.FC<WithdrawModalProps> = ({ isOpen, onClose, onSuccess, currentBalance }) => {
  const [amount, setAmount] = useState<string>('');
  const [bankDetails, setBankDetails] = useState({
    accountHolder: '',
    accountNumber: '',
    ifscCode: '',
    bankName: ''
  });
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  if (!isOpen) return null;

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const withdrawAmount = Number(amount);

    // Updated minimum withdrawal to 100
    if (!withdrawAmount || isNaN(withdrawAmount) || withdrawAmount < 100) {
      alert("Minimum withdrawal amount is ₹100");
      return;
    }

    if (withdrawAmount > currentBalance) {
      alert("Insufficient balance in your wallet.");
      return;
    }

    if (!bankDetails.accountNumber || !bankDetails.ifscCode || !bankDetails.accountHolder) {
      alert("Please fill in all bank details.");
      return;
    }

    setLoading(true);

    // Simulate bank transfer processing
    setTimeout(() => {
      setLoading(false);
      setStatus('success');
      setTimeout(() => {
        onSuccess(withdrawAmount);
        setStatus('idle');
        setAmount('');
        setBankDetails({ accountHolder: '', accountNumber: '', ifscCode: '', bankName: '' });
        onClose();
      }, 2500);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-[2.5rem] overflow-hidden shadow-2xl animate-scale-in">
        
        {status === 'success' ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-24 h-24 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={56} className="animate-bounce" />
            </div>
            <h3 className="text-3xl font-black text-white tracking-tight">Withdrawal Initiated</h3>
            <p className="text-slate-400 font-medium">₹{amount} is being processed to your bank account. It usually takes 2-4 hours.</p>
            <div className="bg-slate-800/50 p-4 rounded-2xl text-left border border-slate-700 mt-6">
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Destination</p>
               <p className="text-white font-bold">{bankDetails.bankName || 'Your Bank Account'}</p>
               <p className="text-xs text-slate-400">Acc: ****{bankDetails.accountNumber.slice(-4)}</p>
            </div>
          </div>
        ) : (
          <>
            <div className="p-8 border-b border-slate-800 flex justify-between items-center bg-slate-800/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-rose-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-rose-900/30">
                  <ArrowUpRight size={22} />
                </div>
                <div>
                  <h3 className="font-black text-white text-xl tracking-tight">Withdraw Funds</h3>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">To Registered Bank Account</p>
                </div>
              </div>
              <button onClick={onClose} className="text-slate-500 hover:text-white transition-all bg-white/5 p-2 rounded-xl">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleWithdraw} className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Withdraw Amount (Min ₹100)</label>
                  <div className="relative">
                    <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="number" 
                      required
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-xl font-bold text-white focus:ring-2 focus:ring-rose-600 focus:outline-none transition-all"
                    />
                  </div>
                  <p className="text-[9px] text-slate-500 font-bold px-1 flex justify-between">
                    <span>Balance: ₹{currentBalance.toLocaleString()}</span>
                    <button type="button" onClick={() => setAmount(currentBalance.toString())} className="text-blue-500 hover:underline">MAX</button>
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Account Holder Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                    <input 
                      type="text" 
                      required
                      value={bankDetails.accountHolder}
                      onChange={(e) => setBankDetails({...bankDetails, accountHolder: e.target.value})}
                      placeholder="As per Bank Records"
                      className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Account Number</label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                      <input 
                        type="text" 
                        required
                        value={bankDetails.accountNumber}
                        onChange={(e) => setBankDetails({...bankDetails, accountNumber: e.target.value})}
                        placeholder="Enter Bank Acc No."
                        className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">IFSC Code</label>
                    <div className="relative">
                      <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                      <input 
                        type="text" 
                        required
                        value={bankDetails.ifscCode}
                        onChange={(e) => setBankDetails({...bankDetails, ifscCode: e.target.value.toUpperCase()})}
                        placeholder="SBIN0001234"
                        className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold text-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Bank Name (Optional)</label>
                  <input 
                    type="text" 
                    value={bankDetails.bankName}
                    onChange={(e) => setBankDetails({...bankDetails, bankName: e.target.value})}
                    placeholder="e.g. HDFC Bank, SBI..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-2xl py-4 px-5 text-sm font-bold text-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white py-5 rounded-[1.5rem] font-black text-xs tracking-widest uppercase shadow-xl shadow-rose-900/30 flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <ArrowUpRight size={20} />
                      CONFIRM WITHDRAWAL
                    </>
                  )}
                </button>
              </div>

              <div className="bg-blue-500/5 p-4 rounded-2xl flex items-start gap-3 border border-blue-500/10">
                <ShieldCheck className="text-blue-500 shrink-0 mt-1" size={18} />
                <div className="space-y-1">
                  <p className="text-[10px] text-white font-black uppercase tracking-widest">Secure Transfer</p>
                  <p className="text-[9px] text-slate-500 leading-relaxed font-medium">
                    Withdrawals are processed through RTGS/NEFT/IMPS. Ensure bank details match your KYC documents to avoid delays.
                  </p>
                </div>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default WithdrawModal;
