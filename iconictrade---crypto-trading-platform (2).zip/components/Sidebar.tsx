
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ArrowLeftRight, 
  Wallet, 
  LineChart, 
  Settings, 
  Bell, 
  Lock, 
  ShieldCheck, 
  Briefcase,
  BookOpen,
  Gift
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isLoggedIn: boolean;
  onAuthRequired: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isLoggedIn, onAuthRequired }) => {
  const [branding, setBranding] = useState({
    name: localStorage.getItem('platform_name') || 'IconicTrade',
    initial: localStorage.getItem('platform_initial') || 'I',
    tagline: localStorage.getItem('platform_tagline') || 'Pro Crypto Trader',
    logoUrl: localStorage.getItem('platform_logo_url') || ''
  });

  useEffect(() => {
    const handleUpdate = () => {
      setBranding({
        name: localStorage.getItem('platform_name') || 'IconicTrade',
        initial: localStorage.getItem('platform_initial') || 'I',
        tagline: localStorage.getItem('platform_tagline') || 'Pro Crypto Trader',
        logoUrl: localStorage.getItem('platform_logo_url') || ''
      });
    };
    window.addEventListener('branding-update', handleUpdate);
    return () => window.removeEventListener('branding-update', handleUpdate);
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, protected: false },
    { id: 'market', label: 'Market', icon: LineChart, protected: false },
    { id: 'trading', label: 'Trading', icon: ArrowLeftRight, protected: false },
    { id: 'portfolio', label: 'Portfolio', icon: Briefcase, protected: true },
    { id: 'academy', label: 'Academy', icon: BookOpen, protected: false },
    { id: 'referral', label: 'Refer & Earn', icon: Gift, protected: true },
    { id: 'admin', label: 'Admin Panel', icon: Lock, protected: true },
  ];

  const handleNav = (item: typeof menuItems[0]) => {
    if (item.protected && !isLoggedIn) {
      onAuthRequired();
    } else {
      setActiveTab(item.id);
    }
  };

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 border-r border-slate-800 hidden lg:flex flex-col z-50">
      <div className="p-6 flex-1">
        <div className="flex items-center gap-3 mb-10">
          {branding.logoUrl ? (
            <img 
              src={branding.logoUrl} 
              alt="Logo" 
              className="w-10 h-10 rounded-xl object-cover shadow-lg shadow-blue-900/20 border border-slate-700"
            />
          ) : (
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center font-bold text-white text-xl italic shadow-lg shadow-blue-900/40">
              {branding.initial}
            </div>
          )}
          <div>
            <span className="text-xl font-bold text-white tracking-tight block leading-none">{branding.name}</span>
            <span className="text-[10px] text-blue-500 font-bold tracking-[0.2em] uppercase">{branding.tagline}</span>
          </div>
        </div>

        <nav className="space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNav(item)}
              className={`w-full flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-xl shadow-blue-900/30 translate-x-1' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <item.icon size={20} className={activeTab === item.id ? 'text-white' : 'group-hover:text-blue-400 transition-colors'} />
                <span className="font-semibold text-sm">{item.label}</span>
              </div>
              {item.protected && !isLoggedIn && <Lock size={14} className="text-slate-600" />}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-6 space-y-1 bg-slate-800/20 m-4 rounded-3xl border border-slate-800/50">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-white transition-colors text-sm font-medium">
          <Settings size={18} />
          <span>Security</span>
        </button>
        <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-2 px-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest">
           <ShieldCheck size={14} className="text-emerald-500" /> Secure
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
