
export interface Coin {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  marketCap: string;
  volume24h: string;
  sparkline: number[];
  logoUrl?: string;
}

export interface Trade {
  id: string;
  type: 'buy' | 'sell';
  asset: string;
  price: number;
  amount: number;
  timestamp: Date;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  status: 'success' | 'pending' | 'failed';
  date: Date;
  method: string;
}

export interface UserPortfolio {
  balanceINR: number;
  assets: {
    symbol: string;
    amount: number;
    avgPrice: number;
  }[];
}

export interface AIInsight {
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  summary: string;
  keyLevels: string[];
  riskFactor: string;
}
