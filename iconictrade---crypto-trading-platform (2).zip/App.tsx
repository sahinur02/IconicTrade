
import React, { useState, useEffect } from 'react';
import { MOCK_COINS } from './constants';
import { Coin, Transaction } from './types';
import Sidebar from './components/Sidebar';
import MarketCard from './components/MarketCard';
import TradingView from './components/TradingView';
import AdminPanel from './components/AdminPanel';
import DepositModal from './components/DepositModal';
import WithdrawModal from './components/WithdrawModal';
import AuthPage from './components/AuthPage';
import AIInsightPanel from './components/AIInsightPanel';
import { 
  Menu, 
  Plus, 
  ArrowUpRight, 
  TrendingUp,
  Wallet,
  IndianRupee,
  LineChart,
  Briefcase,
  Gift,
  CheckCircle2,
  Zap
} from 'lucide-react';

const App: React.FC = () => {
  const [branding, setBranding] = useState({
    name: localStorage.getItem('platform_name') || 'IconicTrade',
    initial: localStorage.getItem('platform_initial') || 'I',
  });

  const [allCoins, setAllCoins] = useState<Coin[]>([...MOCK_COINS]);
  const [intendedTab, setIntendedTab] = useState<string | null>(null);

  // Live Price Ticker Simulation
  useEffect(() => {
    const ticker = setInterval(() => {
      setAllCoins(currentCoins => 
        currentCoins.map(coin => ({
          ...coin,
          price: coin.price * (1 + (Math.random() * 0.002 - 0.001)),
          change24h: Number((coin.change24h + (Math.random() * 0.1 - 0.05)).toFixed(2))
        }))
      );
    }, 3000);
    return () => clearInterval(ticker);
  }, []);

  useEffect(() => {
    const loadCoins = () => {
      const saved = localStorage.getItem('custom_platform_coins');
      if (saved) {
        setAllCoins([...MOCK_COINS, ...JSON.parse(saved)]);
      } else {
        setAllCoins([...MOCK_COINS]);
      }
    };
    loadCoins();
    
    const handleBrandingUpdate = () => {
      setBranding({
        name: localStorage.getItem('platform_name') || 'IconicTrade',
        initial: localStorage.getItem('platform_initial') || 'I',
      });
    };

    window.addEventListener('branding-update', handleBrandingUpdate);
    window.addEventListener('coins-update', loadCoins);
    return () => {
      window.removeEventListener('branding-update', handleBrandingUpdate);
      window.removeEventListener('coins-update', loadCoins);
    };
  }, []);

  const getInitialTab = () => {
    const hash = window.location.hash.replace('#', '');
    const authRoutes = ['login', 'signup'];
    const validTabs = ['dashboard', 'market', 'trading', 'portfolio', 'academy', 'referral', 'admin'];
    
    if (authRoutes.includes(hash)) return 'dashboard';
    return validTabs.includes(hash) ? hash : 'dashboard';
  };

  const [activeTab, setActiveTab] = useState(getInitialTab());
  const [isAuthPage, setIsAuthPage] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [selectedCoin, setSelectedCoin] = useState<Coin>(allCoins[0] || MOCK_COINS[0]);
  
  // User States
  const [balance, setBalance] = useState(0.00);
  const [portfolioAssets, setPortfolioAssets] = useState<{name: string, symbol: string, amount: number, value: number, change: number}[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      
      if (hash === 'login' || hash === 'signup') {
        if (!isLoggedIn) {
          setAuthMode(hash as 'login' | 'signup');
          setIsAuthPage(true);
        } else {
          window.location.hash = intendedTab || 'dashboard';
        }
        return;
      }

      const newTab = getInitialTab();
      const protectedTabs = ['portfolio', 'referral', 'admin', 'trading'];
      
      if (protectedTabs.includes(newTab) && !isLoggedIn) {
        setIntendedTab(newTab);
        setAuthMode('login');
        setIsAuthPage(true);
      } else {
        setActiveTab(newTab);
        setIsAuthPage(false);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [isLoggedIn, intendedTab]);

  const handleTabChange = (tab: string) => {
    window.location.hash = tab;
  };

  const handleAuthSuccess = (userData: { name: string; email: string }, isNewUser: boolean) => {
    setUser(userData);
    setIsLoggedIn(true);
    setIsAuthPage(false);
    
    if (isNewUser) {
      setBalance(0.00);
      setPortfolioAssets([]);
    } else {
      setBalance(25000.00);
      setPortfolioAssets([
        { name: 'Bitcoin', symbol: 'BTC', amount: 0.05, value: 52450.20 * 0.05, change: 2.45 },
      ]);
    }
    
    const destination = intendedTab || 'dashboard';
    setIntendedTab(null);
    handleTabChange(destination);
  };

  const handleTradeExecution = (side: 'buy' | 'sell', coin: Coin, qty: number) => {
    const tradeValue = qty * coin.price;
    if (side === 'buy') {
      setBalance(prev => prev - tradeValue);
      setPortfolioAssets(prev => {
        const existing = prev.find(a => a.symbol === coin.symbol);
        if (existing) {
          return prev.map(a => a.symbol === coin.symbol ? { ...a, amount: a.amount + qty, value: (a.amount + qty) * coin.price } : a);
        }
        return [...prev, { name: coin.name, symbol: coin.symbol, amount: qty, value: tradeValue, change: coin.change24h }];
      });
    } else {
      setBalance(prev => prev + tradeValue);
      setPortfolioAssets(prev => {
        return prev.map(a => a.symbol === coin.symbol ? { ...a, amount: Math.max(0, a.amount - qty), value: Math.max(0, a.amount - qty) * coin.price } : a)
                   .filter(a => a.amount > 0.00000001);
      });
    }

    setTransactions(prev => [{
      id: `TRD-${Date.now()}`,
      type: side === 'buy' ? 'deposit' : 'withdrawal',
      amount: tradeValue,
      status: 'success',
      date: new Date(),
      method: `${side.toUpperCase()} ${coin.symbol}`
    }, ...prev]);
  };

  const totalValue = portfolioAssets.reduce((acc, curr) => {
    const liveCoin = allCoins.find(c => c.symbol === curr.symbol);
    return acc + (curr.amount * (liveCoin?.price || 0));
  }, 0) + balance;

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 rounded-[2.5rem] p-10 text-white shadow-2xl shadow-blue-900/30 relative overflow-hidden group">
                <div className="absolute -top-10 -right-10 opacity-10 transform group-hover:scale-125 transition-all duration-700">
                  <Wallet size={240} />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-2">
                    <IndianRupee size={16} className="text-blue-200" />
                    <p className="text-blue-100 text-sm font-bold tracking-widest uppercase">Wallet Balance</p>
                  </div>
                  <div className="flex items-baseline gap-3 mb-10">
                    <span className="text-5xl font-black tracking-tighter">₹{balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex gap-4">
                    <button onClick={() => isLoggedIn ? setIsDepositModalOpen(true) : handleTabChange('login')} className="flex-1 bg-white text-blue-700 py-4 rounded-2xl font-black text-sm shadow-xl hover:bg-blue-50 transition-all">DEPOSIT</button>
                    <button onClick={() => isLoggedIn ? setIsWithdrawModalOpen(true) : handleTabChange('login')} className="flex-1 bg-blue-800/40 text-white border border-white/20 py-4 rounded-2xl font-black text-sm hover:bg-blue-800/60 transition-all">WITHDRAW</button>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] flex flex-col justify-between group hover:border-emerald-500/30 transition-all shadow-xl">
                  <div>
                    <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 mb-6">
                      <ArrowUpRight size={28} />
                    </div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Live Market</p>
                    <h4 className="text-2xl font-black text-white">{selectedCoin.name}</h4>
                  </div>
                  <div className="mt-4 flex justify-between items-end">
                    <div className="space-y-1">
                      <span className={`text-3xl font-black ${selectedCoin.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {selectedCoin.change24h}%
                      </span>
                    </div>
                    <TrendingUp size={40} className="text-emerald-500/10" />
                  </div>
                </div>
                <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] flex flex-col justify-between group hover:border-blue-500/30 transition-all shadow-xl">
                   <div>
                    <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 mb-6">
                      <Briefcase size={28} />
                    </div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Total Net Worth</p>
                    <h4 className="text-2xl font-black text-white">₹{totalValue.toLocaleString()}</h4>
                  </div>
                   <div className="mt-4 flex justify-between items-end">
                    <div className="space-y-1">
                      <span className="text-3xl font-black text-blue-400">{portfolioAssets.length}</span>
                      <p className="text-xs text-slate-500 font-bold">Assets Held</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-amber-600/20 to-blue-600/20 border border-amber-500/30 p-8 rounded-[2.5rem] flex flex-col md:flex-row items-center justify-between gap-6 cursor-pointer hover:scale-[1.01] transition-all shadow-xl" onClick={() => handleTabChange('referral')}>
               <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-900/40"><Gift size={32} /></div>
                  <div>
                     <h3 className="text-2xl font-black text-white">Earn ₹900 per Referral!</h3>
                     <p className="text-slate-400 font-medium">Rewards are credited instantly after your friend's first deposit.</p>
                  </div>
               </div>
               <button className="bg-amber-500 hover:bg-amber-400 text-slate-900 px-8 py-3 rounded-2xl font-black text-xs tracking-widest transition-all">INVITE NOW</button>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-black text-white">Top Markets</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {allCoins.map(coin => (
                  <MarketCard key={coin.id} coin={coin} onClick={() => { setSelectedCoin(coin); handleTabChange('trading'); }} />
                ))}
              </div>
            </div>
          </div>
        );
      case 'market':
        return (
          <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
            <table className="w-full text-left">
              <thead className="bg-slate-800/50 border-b border-slate-800">
                <tr>
                  <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Asset</th>
                  <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Price</th>
                  <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">24h Change</th>
                  <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {allCoins.map(coin => (
                  <tr key={coin.id} className="hover:bg-slate-800/30 transition-all group cursor-pointer" onClick={() => { setSelectedCoin(coin); handleTabChange('trading'); }}>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        {coin.logoUrl ? <img src={coin.logoUrl} className="w-10 h-10 rounded-xl" /> : <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center font-black text-white">{coin.symbol[0]}</div>}
                        <div><div className="font-black text-white text-lg">{coin.name}</div><div className="text-xs text-slate-500 font-bold">{coin.symbol}/INR</div></div>
                      </div>
                    </td>
                    <td className="px-8 py-6 font-black text-white text-lg">₹{coin.price.toLocaleString()}</td>
                    <td className="px-8 py-6"><span className={coin.change24h > 0 ? 'text-emerald-400' : 'text-rose-400'}>{coin.change24h}%</span></td>
                    <td className="px-8 py-6 text-right"><button className="bg-blue-600 hover:bg-blue-50 text-white px-8 py-3 rounded-2xl text-xs font-black tracking-widest">TRADE</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'trading':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6">
            <TradingView 
              selectedCoin={selectedCoin} 
              availableBalance={balance} 
              portfolioAssets={portfolioAssets}
              onTrade={(side, qty) => handleTradeExecution(side, selectedCoin, qty)} 
            />
            <AIInsightPanel coin={selectedCoin} />
          </div>
        );
      case 'portfolio':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6">
             <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-10 flex flex-col md:flex-row items-center justify-between gap-10">
                <div>
                  <p className="text-slate-500 text-sm font-black uppercase tracking-widest mb-1">Portfolio Value</p>
                  <h2 className="text-5xl font-black text-white">₹{totalValue.toLocaleString()}</h2>
                </div>
                <button onClick={() => setIsDepositModalOpen(true)} className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl">ADD FUNDS</button>
             </div>

             <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-xl">
                <div className="p-8 border-b border-slate-800 font-black text-white text-xl">My Digital Assets</div>
                <table className="w-full text-left">
                  <thead className="bg-slate-800/30">
                    <tr>
                      <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Asset</th>
                      <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Holdings</th>
                      <th className="px-8 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Current Value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                     {portfolioAssets.map((asset, i) => (
                       <tr key={i} className="hover:bg-slate-800/20">
                         <td className="px-8 py-6 font-black text-white">{asset.name}</td>
                         <td className="px-8 py-6 font-bold text-slate-300">{asset.amount.toFixed(4)} {asset.symbol}</td>
                         <td className="px-8 py-6 font-black text-white">₹{(asset.amount * (allCoins.find(c => c.symbol === asset.symbol)?.price || 0)).toLocaleString()}</td>
                       </tr>
                     ))}
                     <tr className="bg-blue-600/5">
                        <td className="px-8 py-6 font-black text-white">Indian Rupee (INR)</td>
                        <td className="px-8 py-6 font-bold text-slate-300">₹{balance.toLocaleString()}</td>
                        <td className="px-8 py-6 font-black text-white">₹{balance.toLocaleString()}</td>
                     </tr>
                  </tbody>
                </table>
             </div>
          </div>
        );
      case 'admin':
        return <AdminPanel />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-200">
      <Sidebar activeTab={activeTab} setActiveTab={handleTabChange} isLoggedIn={isLoggedIn} onAuthRequired={() => handleTabChange('login')} />
      <main className="flex-1 lg:ml-64 relative min-h-screen">
        <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-2xl border-b border-slate-800 h-24 flex items-center justify-between px-8 lg:px-12">
          <div className="flex items-center gap-6">
            <button className="lg:hidden text-slate-400 bg-slate-900 p-2.5 rounded-xl border border-slate-800" onClick={() => handleTabChange('dashboard')}><Menu size={24} /></button>
            <h1 className="font-black text-xl text-white tracking-tighter hidden md:block">{branding.name} Markets</h1>
          </div>

          <div className="flex items-center gap-5">
            {isLoggedIn ? (
              <div className="flex items-center gap-4">
                <div onClick={() => setIsDepositModalOpen(true)} className="flex items-center gap-3 px-5 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl cursor-pointer hover:border-blue-500/30 transition-all">
                  <IndianRupee size={16} className="text-blue-500" />
                  <span className="text-sm font-black text-white">₹{balance.toLocaleString()}</span>
                  <Plus size={16} className="text-blue-500" />
                </div>
                <button onClick={() => { setIsLoggedIn(false); setUser(null); handleTabChange('dashboard'); }} className="text-rose-500 font-black text-xs uppercase tracking-widest px-4 py-2 hover:bg-rose-500/10 rounded-xl transition-all">SIGN OUT</button>
              </div>
            ) : (
              <button onClick={() => handleTabChange('login')} className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 rounded-2xl font-black text-xs tracking-widest shadow-xl">GET STARTED</button>
            )}
          </div>
        </header>

        <div className="p-8 lg:p-12 max-w-7xl mx-auto pb-32">
          {isAuthPage ? (
            <AuthPage initialMode={authMode} onSuccess={handleAuthSuccess} onBack={() => handleTabChange('dashboard')} />
          ) : (
            renderContent()
          )}
        </div>

        {/* Mobile Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-slate-950/80 backdrop-blur-xl border-t border-slate-800 flex justify-around items-center h-20 lg:hidden z-50 px-6">
           {[
             { id: 'dashboard', icon: TrendingUp, label: 'Home' },
             { id: 'market', icon: LineChart, label: 'Market' },
             { id: 'trading', icon: Zap, label: 'Trade' },
             { id: 'portfolio', icon: Briefcase, label: 'Assets' },
             { id: 'referral', icon: Gift, label: 'Earn' },
           ].map((item) => (
             <button key={item.id} onClick={() => handleTabChange(item.id)} className={`flex flex-col items-center gap-1.5 ${activeTab === item.id ? 'text-blue-500' : 'text-slate-500'}`}>
                <item.icon size={22} />
                <span className="text-[9px] font-black uppercase tracking-widest">{item.label}</span>
             </button>
           ))}
        </div>

        <DepositModal isOpen={isDepositModalOpen} onClose={() => setIsDepositModalOpen(false)} onSuccess={(amt) => setBalance(b => b + amt)} />
        <WithdrawModal isOpen={isWithdrawModalOpen} onClose={() => setIsWithdrawModalOpen(false)} onSuccess={(amt) => setBalance(b => b - amt)} currentBalance={balance} />
      </main>
    </div>
  );
};

export default App;
