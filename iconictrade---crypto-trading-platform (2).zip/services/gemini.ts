
import { GoogleGenAI, Type } from "@google/genai";
import { AIInsight } from "../types";

// Always use the process.env.API_KEY directly for initialization as per @google/genai guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMarketAnalysis = async (coinName: string, price: number, change: number): Promise<AIInsight | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze the market sentiment for ${coinName} (Current Price: $${price}, 24h Change: ${change}%). Provide a professional trading insight. Return only valid JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: { type: Type.STRING, enum: ['Bullish', 'Bearish', 'Neutral'] },
            summary: { type: Type.STRING },
            keyLevels: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            riskFactor: { type: Type.STRING }
          },
          required: ['sentiment', 'summary', 'keyLevels', 'riskFactor']
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    
    try {
      return JSON.parse(text) as AIInsight;
    } catch (parseError) {
      console.warn("AI returned invalid JSON, attempting fallback parsing.");
      return null;
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};

export const getAITradingAdvisor = async (query: string): Promise<string> => {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are IconicTrade AI, a helpful crypto trading advisor. A user asks: "${query}". Provide a concise, helpful, and data-driven response. Keep it safe and remind them crypto is volatile. Do not use Markdown formatting like bolding or lists unless necessary.`,
      });
      return response.text || "I'm having trouble analyzing the market right now.";
    } catch (error) {
      return "Error connecting to IconicTrade AI engine.";
    }
}
